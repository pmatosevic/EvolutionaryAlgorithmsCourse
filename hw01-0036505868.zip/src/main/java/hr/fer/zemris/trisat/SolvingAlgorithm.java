package hr.fer.zemris.trisat;

public interface SolvingAlgorithm {

    BitVector solve(SATFormula satFormula);

}
