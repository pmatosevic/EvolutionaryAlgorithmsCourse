package hr.fer.zemris.optjava.dz5;

public interface Crossover<T> {

    public T crossover(T first, T second);

}
