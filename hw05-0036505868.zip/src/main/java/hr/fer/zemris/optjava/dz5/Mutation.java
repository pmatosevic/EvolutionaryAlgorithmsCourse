package hr.fer.zemris.optjava.dz5;

import java.util.List;

public interface Mutation<T> {

    public void mutate(T c);

}
