Za n=10 algoritam najbr�e konvergira prema maksimumu kad se za oba roditelja radi k-turnirska selekcija i to sa �to manjim k.
Za n=100 i n=1000 algoritam �esto zapinje na platou i u tom slu�aju se jednako pona�a bez obzira na selekciju i izbor k.
Kri�anje se provodi jednostavnim kri�anjem s jednom to�kom prekida, a mutacija mijenjanjem individualnih bitova uz vjerojatnost od 1/n.
Kontinuiranim pove�avanjem CompFactor mo�e se ubrzati konvergencija prema maksimumu, ali samo za mali n.
