package hr.fer.zemris.optjava.dz9;

public enum SolutionSpace {

    DECISION_SPACE,
    OBJECTIVE_SPACE;

}
