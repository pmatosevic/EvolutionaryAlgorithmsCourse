package hr.fer.zemris.optjava.dz9;

public class Chromosome {

    public double[] solution;
    public double[] objectives;
    public double fitness;

    public Chromosome(double[] solution) {
        this.solution = solution;
    }

}
