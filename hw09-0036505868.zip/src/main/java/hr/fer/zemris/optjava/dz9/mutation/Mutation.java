package hr.fer.zemris.optjava.dz9.mutation;

import hr.fer.zemris.optjava.dz9.Chromosome;

public interface Mutation {

    void mutate(Chromosome c);

}
