package hr.fer.zemris.optjava.dz4.part1.mutation;

import hr.fer.zemris.optjava.dz4.part1.Chromosome;

public interface Mutation {

    void mutate(Chromosome chromosome);

}
