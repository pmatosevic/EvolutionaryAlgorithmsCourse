package hr.fer.zemris.optjava.dz4.part1.function;

public interface IFunction {

    double valueAt(double[] point);

}
