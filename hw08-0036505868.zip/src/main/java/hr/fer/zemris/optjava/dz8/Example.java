package hr.fer.zemris.optjava.dz8;

public class Example {
    public final double[] input;
    public final double[] output;

    public Example(double[] input, double[] output) {
        this.input = input;
        this.output = output;
    }
}