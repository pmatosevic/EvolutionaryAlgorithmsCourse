package hr.fer.zemris.optjava.dz8.ann;

import hr.fer.zemris.optjava.dz8.Dataset;

public class TimeDelayedNN extends ANN {

    public TimeDelayedNN(int[] layers, TransferFunction[] transferFunctions, Dataset dataset) {
        super(layers, transferFunctions, dataset);
    }


}
