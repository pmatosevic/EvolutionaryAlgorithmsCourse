package hr.fer.zemris.optjava.dz8;

public interface Algorithm {

    double[] run(int maxIter, double minErr);

}
