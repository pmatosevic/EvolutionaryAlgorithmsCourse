package hr.fer.zemris.optjava.dz8.ann;

public interface TransferFunction {

    double calculate(double x);

}
