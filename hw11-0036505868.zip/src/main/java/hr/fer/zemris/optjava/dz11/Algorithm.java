package hr.fer.zemris.optjava.dz11;

public interface Algorithm {

    Chromosome run(int maxIter, double minFitness);

}
