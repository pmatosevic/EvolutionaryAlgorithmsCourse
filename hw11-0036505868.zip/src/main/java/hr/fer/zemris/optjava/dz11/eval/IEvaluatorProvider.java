package hr.fer.zemris.optjava.dz11.eval;

public interface IEvaluatorProvider {

    public Evaluator getEvaluator();

}
