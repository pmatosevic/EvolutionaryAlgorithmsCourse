package hr.fer.zemris.optjava.dz11.mutation;

import hr.fer.zemris.optjava.dz11.Chromosome;

public interface Mutation {

    void mutate(Chromosome c);

}
