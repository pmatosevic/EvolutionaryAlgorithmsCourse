package hr.fer.zemris.generic.ga;

public interface IGAEvaluator<T> {
    public void evaluate(GASolution<T> p);
}