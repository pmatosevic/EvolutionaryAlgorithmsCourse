package hr.fer.zemris.optjava.hw03.function;

public interface IFunction {

    double valueAt(double[] point);

}
