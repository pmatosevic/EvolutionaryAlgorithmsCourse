package hr.fer.zemris.optjava.dz7;

public interface Algorithm {

    double[] run(int maxIter, double minErr);

}
