package hr.fer.zemris.optjava.dz7.ann;

public interface TransferFunction {

    double calculate(double x);

}
